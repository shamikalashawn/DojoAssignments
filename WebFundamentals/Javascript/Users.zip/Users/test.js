for (var i = 60; i >= 0; i--) {
  if (i > 30)
  {console.log(i + " days until my birthday.");
} else if (i <= 30)
  {console.log("It's only " + i + " days until my bday");
} else if (i <= 5)
{console.log(i + " DAYS!!!");
} else if (i === 0)
 {console.log("IT'S MY MF'N BDAY!!!");
  }
} 
