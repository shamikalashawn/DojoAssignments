# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.shortcuts import render
from .models import Book
from datetime import datetime

# Create your views here.

def index(request):
    book1 = Book.objects.create(title='Where the Wild Things Are', author='Maurice Sendak', published_date=datetime(1963, 04, 9))
    book2 = Book.objects.create(title="Charlotte's Web", author='E.B. White', published_date=datetime(1952, 10, 15))
    book3 = Book.objects.create(title='Winnie the Pooh', author='A. A. Milne', published_date=datetime(1926, 10, 14))
    book4 = Book.objects.create(title="Alice's Adventures in Wonderland", author='Lewis Carroll', published_date=datetime(1865, 11, 26))
    book5 = Book.objects.create(title='Goodnight Moon', author='Margaret Wise Brown', published_date=datetime(1947, 9, 3))
    books = Book.objects.all()
    def printObjects(obj):
        for item in obj:
            print item.title, item.author, item.published_date
    printObjects(books)
    return render(request, 'BooksApp/index.html')
