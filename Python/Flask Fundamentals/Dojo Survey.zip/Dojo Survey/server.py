from flask import Flask, render_template, redirect, request
app = Flask(__name__)
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/result', methods=['POST'])
def result():
    name = request.form['name']
    location = request.form['location']
    favLanguage = request.form['favLanguage']
    comment = request.form['comment']

    if len(name) < 2:
        flash('Name needs to be at least 2 characters')
        return redirect('/')

    return render_template('result.html', name=name, location=location, favLanguage = favLanguage, comment=comment)

@app.route('/clear')
def clear():
    return redirect('/')
app.run(debug=True)
