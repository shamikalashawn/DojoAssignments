export class Product{
    title: string;
    price: number;
    imageUrl: string;
}