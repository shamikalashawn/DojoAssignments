#Message Board

1. Dependencies
  + express
  + body-parser
  + ejs
  + mongoose

2. Tasks
  + Set up ejs file
  + Set up server
  + Set up database
  + Set up logic for database
  + Set up routes
