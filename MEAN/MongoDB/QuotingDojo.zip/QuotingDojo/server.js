const express = require('express');
const app = express();
const path = require('path');
const port = process.env.PORT || 8000;
const parser = require('body-parser');
const mongoose = require('mongoose');
const moment = require('moment');
app.use(parser.urlencoded({extended: true}));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, './views'));
mongoose.connect('mongodb://localhost/quoting_dojo');
mongoose.Promise = global.Promise;
var QuoteSchema = new mongoose.Schema({
  author: {type:String, required:[true, 'Author must be entered']},
  quote: {type:String, required:[true, 'Quote must be entered']},
  likes: {type: Number, default: 0}
}, {timestamps: true});
mongoose.model('Quote', QuoteSchema);
var Quote = mongoose.model('Quote');
app.get('/', function (req, res) {
  res.render('index');
});
app.get('/quotes', function (req, res) {
  Quote.find({}).sort('-date').exec(function (err, quotes) {
    if (err) {
      res.render('index', {title: error, error: err})
    }
    res.render('quotes', {quotes: quotes, moment:moment});
  });
});
app.get('/likes/:quoteId', function (req, res) {
  // Quote.findByIdAndUpdate(req.params.quoteID, {$inc:{likes: 1}}, function (err, quote) {
  //   if (err) {
  //     console.log('something went wrong.');
  //   }
  //   console.log(`quote has been updated: ${quote}.`);
  //   res.redirect('/quotes');
  // });
  // Quote.findById(req.params.quoteId, function (err, quote) {
  //   if (err) {
  //     console.log('error!');
  //   }
  //   quote.likes.$inc();
  //   quote.save(function (err, updatedQuote) {
  //   if (err) {
  //     console.log('error!');
  //   }
  //   res.redirect('/quotes');
  //   });
  // });
  Quote.update(
    {_id: req.params.quoteId},
    {$inc: {likes: 1}},
    function (err, updatedQuote) {
      if (err) {
        console.log('error!');
      }
      console.log(`updated quote: ${updatedQuote}`);
      res.redirect('/quotes');
    });
});
app.post('/quotes', function (req, res) {
  console.log('POST DATA: ', req.body);
  //add quote to db
  var quote = new Quote({author:req.body.name, quote:req.body.quote});
  quote.save(function (err) {
    if (err) {
      res.render('index', {title:'something went wrong', error: quote.errors})
    }
    res.redirect('/quotes');
  })
  //in save function, deal with error and redirect on success
});
app.listen(port, function () {
  console.log(`Listening on port ${port}.`);
});
