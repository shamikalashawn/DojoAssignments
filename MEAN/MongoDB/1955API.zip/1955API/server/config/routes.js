const mongoose = require('mongoose');
const Person = mongoose.model('Person');
const person = require('../controllers/person.js');

module.exports = function (app) {
  app.get('/', function (req, res) {
    person.showAll(req, res);
  });
  app.get('/new/:name', function (req, res) {
    person.create(req, res);
  });
  app.get('/remove/:name', function (req, res) {
    person.destroy(req, res);
  });
  app.get('/:name', function (req, res) {
    person.showOne(req, res);
  });
}
