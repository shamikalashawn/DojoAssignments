$(document).ready(function () {
  //when user presses enter, another button with the same functionality appears
  document.onkeydown = function (a) {
    var btndiv = document.getElementById('newbtns');
    if (a.keyCode === 13) {
      btndiv.innerHTML += "<button type='button' name='button'>Click Me</button>";
    }
  }
  $('button').each(function () {
    $('body').on('click', 'button', function () {
      if ($(this).attr('color') == 'red'){
        $(this).css("background-color", "blue");
        $(this).attr('color', 'blue');
      }
      else{
        $(this).css("background-color", "red");
        $(this).attr('color', 'red');
      }
    });
  });
  var currcolor;
  $('button').each(function () {
    $('body').on('mouseover', 'button', function () {
      currcolor = $(this).attr('color');
      $(this).css("background-color", "green");
      $(this).attr('color', 'green');
    });
  });

  $('button').each(function () {
    $('body').on('mouseout', 'button', function () {
      if($(this).attr('color') == 'green'){
        $(this).css("background-color", currcolor);
        $(this).attr('color', currcolor);
      }
    });
  });
});
