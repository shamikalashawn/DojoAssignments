var mathlib = require('./mathlib')();

console.log(mathlib.add(1,1));
console.log(mathlib.multiply(2,2));
console.log(mathlib.square(5));
console.log(mathlib.random(2,5));
